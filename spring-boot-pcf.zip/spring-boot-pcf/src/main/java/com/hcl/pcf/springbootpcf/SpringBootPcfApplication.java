package com.hcl.pcf.springbootpcf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPcfApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPcfApplication.class, args);
	}

}
